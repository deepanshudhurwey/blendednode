import { Accordian } from './accordian/accordian.component';
import { Tabs } from './tabs/tabs.component';
import { Modal } from './modal/modal.component';
import { Popover } from './popover/popover.component';
import { Toast } from './toast/toast.component';

    import { Table } from './table/table.component';
import { HeaderComponent } from '../shared/components/header/header.component';

    import { Badge } from './badge/badge.component';
import { FooterComponent } from '../shared/components/footer/footer.component';

    
    import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
    import { FormsModule, ReactiveFormsModule } from '@angular/forms';
    import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
    import { CommonModule } from '@angular/common';;
    import { DynamicHooksModule, HookParserEntry } from 'ngx-dynamic-hooks';
    const componentParsers: Array<HookParserEntry> = [
    
    
    {
              component:  HeaderComponent
            },
    
    {
              component:  FooterComponent
            },
    
       
      ];
      
     

    @NgModule({
    declarations: [
    Accordian,
Tabs,
Modal,
Popover,
Toast,
 
    
    
    Table,
HeaderComponent, 
    
    
    Badge,
FooterComponent, 
    
    
        
        
    ],
    imports: [
        
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    DynamicHooksModule,
    DynamicHooksModule.forRoot({
        globalParsers: componentParsers
      })
    ],
    providers: [
        
    ],
    exports: [
    Accordian,
Tabs,
Modal,
Popover,
Toast,

    
    Table,
HeaderComponent,
    
    Badge,
FooterComponent,
    
        
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    export class CommonComponentsModule { }
    
        
        
        