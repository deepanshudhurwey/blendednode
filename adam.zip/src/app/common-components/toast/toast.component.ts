
    import { Component, Input, OnInit } from '@angular/core';

    @Component({
        selector: 'app-toast',
        templateUrl: './toast.component.html',
        styleUrls: ['./toast.component.scss']
    })

    export class Toast implements OnInit {
        @Input() data?: any;
        active = 1;
        show = false;
        
        constructor() {  }

        ngOnInit() {

         
                this.data.body = `<app-${this.data.body}></app-${this.data.body}>`
           

        }
    }
    