
    import { Component, Input, OnInit } from '@angular/core';

    @Component({
        selector: 'app-accordian',
        templateUrl: './accordian.component.html',
        styleUrls: ['./accordian.component.scss']
    })

    export class Accordian implements OnInit {
        @Input() data?: any;
        constructor() {  }

        ngOnInit() {
            for(let i = 0; i<this.data.length ; i++){ 
                if(this.data[i].flag){        
                if(this.data[i].value){
                this.data[i].value = `<app-${this.data[i].value}></app-${this.data[i].value}>`
                }  
             }
            }
              
        }
    }
    