
    import { Component, Input, OnInit } from '@angular/core';

    @Component({
        selector: 'app-tabs',
        templateUrl: './tabs.component.html',
        styleUrls: ['./tabs.component.scss']
    })

    export class Tabs implements OnInit {
        @Input() data?: any;
        active = 1;
        constructor() {  }

        ngOnInit() {
            for(let i = 0; i<this.data.length ; i++){  
                if(this.data[i].flag){       
                if(this.data[i].value){
                this.data[i].value = `<app-${this.data[i].value}></app-${this.data[i].value}>`
                }            
             }
            }
        }
    }
    