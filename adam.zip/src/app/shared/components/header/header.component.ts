
    import { Component, OnInit } from '@angular/core';
    import { FormBuilder } from '@angular/forms';
    import { FormControl, Validators } from '@angular/forms';
    import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

    @Component({
        selector: 'app-header',
        templateUrl: './header.component.html',
        styleUrls: ['./header.component.scss']
    })
    export class HeaderComponent implements OnInit {
        active = 1;
        show = false;
        page = 1;
        
      tableData = JSON.parse(JSON.stringify({"border":"","data":[{"HEADER_TITLE_0":"DATA_ROW_00","HEADER_TITLE_2":"DATA_ROW_02","HEADER_TITLE_1":"DATA_ROW_01"},{"HEADER_TITLE_0":"DATA_ROW_10","HEADER_TITLE_2":"DATA_ROW_12","HEADER_TITLE_1":"DATA_ROW_11"},{"HEADER_TITLE_0":"DATA_ROW_20","HEADER_TITLE_2":"DATA_ROW_22","HEADER_TITLE_1":"DATA_ROW_21"},{"HEADER_TITLE_0":"DATA_ROW_30","HEADER_TITLE_2":"DATA_ROW_32","HEADER_TITLE_1":"DATA_ROW_31"},{"HEADER_TITLE_0":"DATA_ROW_40","HEADER_TITLE_2":"DATA_ROW_42","HEADER_TITLE_1":"DATA_ROW_41"}],"devicewidth":"","customclass":"","globalsearch":"","pageSize":"","tablesort":"","databind":"","tableName":"Employee details","fixedHeader":"","size":"","grid":"","columnsearch":"","tableId":"13","header":["HEADER_TITLE_0","HEADER_TITLE_1","HEADER_TITLE_2"],"row":"","databindname":"emp details"}));
  
        
        constructor(private formBuilder: FormBuilder,private modalService: NgbModal,) {  }

        ngOnInit() {
            
        }

        
    }