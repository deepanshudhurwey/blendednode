
    import { Component, OnInit } from '@angular/core';
    import { FormBuilder } from '@angular/forms';
    import { FormControl, Validators } from '@angular/forms';
    import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

    @Component({
        selector: 'app-footer',
        templateUrl: './footer.component.html',
        styleUrls: ['./footer.component.scss']
    })
    export class FooterComponent implements OnInit {
        active = 1;
        show = false;
        page = 1;
        
        badgeData = JSON.parse(JSON.stringify({"button_name":"dev","badge_count":"1000"}));
    
        
        constructor(private formBuilder: FormBuilder,private modalService: NgbModal,) {  }

        ngOnInit() {
            
        }

        
    }