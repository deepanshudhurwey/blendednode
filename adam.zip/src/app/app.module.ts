import { CommonModule } from '@angular/common';
        import { BrowserAnimationsModule } from '@angular/platform-browser/animations';import { CommonComponentsModule } from './common-components/common-components.module'; import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AccessDeniedModule } from './access-denied/access-denied.module';
import { LoginModule } from './login/login.module';
import { NotFoundModule } from './not-found/not-found.module';
import { ServerErrorModule } from './server-error/server-error.module';
import { FooterComponent } from './shared/components/footer/footer.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { SignupModule } from './signup/signup.module';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    
    
    HomeComponent
  ],
  imports: [ 
      CommonComponentsModule
      
        ,CommonModule,
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule
        , BrowserModule,
    AppRoutingModule,
    AccessDeniedModule,
    LoginModule,
    NotFoundModule,
    ServerErrorModule,
    SignupModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
