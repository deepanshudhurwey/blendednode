
    import { Component, OnInit } from '@angular/core';
    import { FormBuilder } from '@angular/forms';
    import { FormControl, Validators } from '@angular/forms';
    import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

    @Component({
        selector: 'app-home',
        templateUrl: './home.component.html',
        styleUrls: ['./home.component.scss']
    })
    export class HomeComponent implements OnInit {
        active = 1;
        show = false;
        page = 1;
        
        accordionData = JSON.parse(JSON.stringify([{"title":"acc","value":"accc1","flag":0},{"title":"acc","value":"Footer","flag":1},{"title":"acc","value":"Header","flag":1}]));
    
        tabsData = JSON.parse(JSON.stringify({"data":[{"title":"t1","value":"Footer","flag":1},{"title":"t11","value":"Header","flag":1},{"title":"t111","value":"t","flag":0}]}));
    
          modalData = JSON.parse(JSON.stringify({"launch_button":"Save Changes","flag":1,"title":"mmm","body":"Footer","size":"lg","close_button":"Close"}));
      
      popoverData = JSON.parse(JSON.stringify({"title":"ppp","content":"Footer","flag":1}));
  
        toastData = JSON.parse(JSON.stringify({"body":"Footer","header":"ttttt","flag":1}));
    
        
        constructor(private formBuilder: FormBuilder,private modalService: NgbModal,) {  }

        ngOnInit() {
            
        }

        
    }